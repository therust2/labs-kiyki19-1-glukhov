![Alt text](./static/1.png "DEMONSTRATION OF CHAT")
<h1>SCREENSHOT OF CHAT!</h1><br><br>