![Alt text](./static/1.png "HOME SCREEN")
<h1>HOME SCREEN WITH ALL REQUESTS</h1><br><br>
