<?php
    require_once __DIR__ . "/../vendor/autoload.php";
    $client = new MongoDB\Client("mongodb://localhost:27017");

    echo "Connection to database successfully";
    // select a database
    $db = $m->dbforlab;

    echo "Database dbforlab selected";
?>