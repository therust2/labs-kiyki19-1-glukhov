
![Alt text](./static/1.png "HOME SCREEN")
<h1>HOME SCREEN</h1><br><br>

![Alt text](./static/2.png "SEARCH GENRE")
<h1>Result of searching by genre</h1><br><br>


![Alt text](./static/3.png "SEARCH ACTOR")
<h1>Result of searching by Actor</h1><br><br>

![Alt text](./static/3.png "SEARCH BY YEARS")
<h1>Result of searching by Years</h1><br><br>